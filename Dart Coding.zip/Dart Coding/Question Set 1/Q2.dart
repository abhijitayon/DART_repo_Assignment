// #2 Write a program to print Hello I am “John Doe” and Hello I’am “John Doe” with single and double quotes.

void main(){
  print("Hello I am \"John Doe\" and Hello I\'am \"John Doe\"");
}
